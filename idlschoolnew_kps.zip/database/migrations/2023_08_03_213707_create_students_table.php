<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->integer('id', true);
            $table->string('roll_no', 10);
            $table->string('name', 150);
            $table->string('adminssion_number', 8);
            $table->integer('parent_id')->index('parent');
            $table->integer('class_id')->index('Class');
            $table->integer('session_id')->nullable();
            $table->date('dob');
            $table->string('b_form', 25);
            $table->enum('gender', ['Male', 'Female'])->default('Male');
            $table->integer('monthly_fee');
            $table->boolean('subling')->nullable();
            $table->enum('religion', ['Islam', 'Christian'])->default('Islam');
            $table->enum('status', ['enable', 'disable'])->default('enable');
            $table->timestamp('updated_at')->useCurrent();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
};
