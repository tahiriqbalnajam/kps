<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubjectToClass extends Model
{
    public $timestamps = false;
    protected $table = "subject_to_classes";
}
