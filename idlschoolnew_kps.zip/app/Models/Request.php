<?php

namespace App\Models;

class Request extends Model
{
    public $guarded = ['id'];

    public $timestamps = false;
}