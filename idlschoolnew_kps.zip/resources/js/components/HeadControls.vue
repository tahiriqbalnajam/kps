<template>
    <el-card  :body-style="{ padding: '15px 0 0 15px' }" shadow="never">
        <div class="flex">
            <slot>
                Control will be here.
            </slot>
        </div>
    </el-card>
</template>

<script setup>
</script>