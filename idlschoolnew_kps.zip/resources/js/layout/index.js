import component from './Layout.vue'

export default component
