import component from './TagsView.vue'
export default component
