import component from './Breadcrumb.vue'
export default component
