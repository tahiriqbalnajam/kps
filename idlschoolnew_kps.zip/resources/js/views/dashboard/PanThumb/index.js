import component from './PanThumb.vue'
export default component
