import component from './Editor.vue'
export default component
