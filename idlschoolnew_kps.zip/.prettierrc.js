module.exports = {
  singleQuote: true,
  semi: true,
  tabWidth: 2,
  trailingComma: 'es5',
}
